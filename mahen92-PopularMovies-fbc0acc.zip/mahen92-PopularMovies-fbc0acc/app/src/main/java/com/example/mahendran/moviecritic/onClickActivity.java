package com.example.mahendran.moviecritic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class onClickActivity extends AppCompatActivity {

    User user =null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_click);
        ImageView img = (ImageView) findViewById(R.id.clickImage);
        TextView address = (TextView) findViewById(R.id.address);
        TextView date = (TextView) findViewById(R.id.date);
        TextView orig = (TextView) findViewById(R.id.original);
        TextView vote = (TextView) findViewById(R.id.vote);
        TextView title = (TextView) findViewById(R.id.title);
        TextView lines = (TextView) findViewById(R.id.lines);
        Intent intent=this.getIntent();

        user = intent.getParcelableExtra("key");
        Picasso.with(this).load(user.getAvatar()).into(img);
        date.setText("Website :"+ user.getAddress());
        vote.setText("Date Of Birth:"+ user.getWebsite());
        title.setText("Blog Title:"+ user.getTitle());
        String[] splits=user.getLines().split("\n",2);
        lines.setText(splits[0]);
        orig.setText(user.getName());
            }
        }



