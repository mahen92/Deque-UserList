package com.example.mahendran.moviecritic;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

/**
 * Created by Mahendran
 */

public class User implements Parcelable{

    private String name;
    private String email;
    private String gender;
    private String phone;
    private String id;
    private String avatar;
    private String status;
    private String title;
    private String lines;
    private String website;
    private String address;
    private String dob;

    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Flatten this object in to a Parcel.
     *
     * @param out  The Parcel in which the object should be written.
     * @param flags Additional flags about how the object should be written.
     *              May be 0 or {@link #PARCELABLE_WRITE_RETURN_VALUE}.
     */
    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(name);
        out.writeString(email);
        out.writeString(gender);
        out.writeString(phone);
        out.writeString(id);
        out.writeString(avatar);
        out.writeString(status);
        out.writeString(title);
        out.writeString(lines);
        out.writeString(address);
        out.writeString(website);
        out.writeString(dob);
    }

    public static final Creator<User> CREATOR
            = new Creator<User>(){
        /**
         * Create a new instance of the Parcelable class, instantiating it
         * from the given Parcel whose data had previously been written by
         * {@link Parcelable#writeToParcel Parcelable.writeToParcel()}.
         *
         * @param in The Parcel to read the object's data from.
         * @return Returns a new instance of the Parcelable class.
         */
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        /**
         * Create a new array of the Parcelable class.
         *
         * @param size Size of the array.
         * @return Returns an array of the Parcelable class, with every entry
         * initialized to null.
         */
        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    private User(Parcel in){
        name = in.readString();
        email = in.readString();
        gender = in.readString();
        phone = in.readString();
        id = in.readString();
        avatar = in.readString();
        status = in.readString();
        title = in.readString();
        lines = in.readString();
        website = in.readString();
        address = in.readString();
        website = in.readString();
        dob = in.readString();
    }

    public User(String id, String name, String gender, String email, String phone, String avatar, String status, String title, String lines, String address, String website, String dob){
        Log.v("DebbuggerMovie","title:"+title+" lines:" +lines+" address"+address+" website"+website+" dob"+dob);
        this.id = id;
        this.email = email;
        this.gender = gender;
        this.phone = phone;
        this.name = name;
        this.avatar = avatar;
        this.status=status;
        this.title=title;
        this.lines=lines;
        this.address=address;
        this.website=website;
        this.dob=dob;
        }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getId() {
        return id;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getPhone() {
        return phone;
    }

    public String getStatus() {
        return status;
    }

    public String getTitle(){ return title;}

    public String getLines(){ return lines;}

    public String getDOB(){

        return dob;}

    public String getAddress(){
        return address;}

    public String getWebsite(){
        return website;}
}
