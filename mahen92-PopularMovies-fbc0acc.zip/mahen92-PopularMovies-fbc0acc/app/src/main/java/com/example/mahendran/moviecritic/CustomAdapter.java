package com.example.mahendran.moviecritic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Mahendran
 */
public class CustomAdapter extends ArrayAdapter implements View.OnTouchListener {
    private Context context;
    private LayoutInflater inflater;
    ArrayList<User> userList =new ArrayList<>();
    User[] users;

    public CustomAdapter(Context context, ArrayList<User> imageUrls) {
        super(context, R.layout.list_items, imageUrls);
        this.context=context;
        userList =imageUrls;
        inflater=LayoutInflater.from(context);
        }

    public long getItemId(int position)
    {
        return position;
    }
    public View getView(int position, View convertView, ViewGroup parent)
    {
        if (null == convertView) {
            convertView = inflater.inflate(R.layout.list_items, parent, false);
        }
        if((userList.size()!=0)&&(userList !=null)) {
            users = userList.toArray(new User[userList.size()]);
            ImageView imageView=(ImageView)convertView.findViewById(R.id.list_images);
            Picasso.with(context).load((users[position].getAvatar())).fit().into(imageView);
            TextView name=(TextView)convertView.findViewById(R.id.name);
            TextView email=(TextView)convertView.findViewById(R.id.email);
            ImageView gender=(ImageView)convertView.findViewById(R.id.gender);
            TextView phone=(TextView)convertView.findViewById(R.id.phone);
            TextView status=(TextView)convertView.findViewById(R.id.status);

            name.setText(users[position].getName());
            email.setText(users[position].getEmail());
            if(users[position].getGender().equals("female"))
            {
                gender.setImageResource(R.drawable.female);
            }
            else
            {
                gender.setImageResource(R.drawable.male);
            }

            phone.setText(users[position].getPhone());
            status.setText(users[position].getStatus());
        }

        return convertView;
    }
    public User getItem(int position){
        return userList.get(position);
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;
    }
}
