package com.example.mahendran.moviecritic;

public class BlogObject {
    String title;
    String lines;

    public BlogObject(String title, String lines) {
        this.title = title;
        this.lines = lines;
    }

    public String getTitle() {
        return title;
    }

    public String getLines() {
        return lines;
    }
}
